import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY_ENV_VAR || ""
});

export interface HighlightDetection {
  timestamp: number;
  duration: number;
  description: string;
  viralPotential: number;
  confidence: number;
}

export interface ViralAnalysis {
  score: number;
  factors: string[];
  recommendations: string[];
  confidence: number;
}

export interface ContentStrategy {
  title: string;
  description: string;
  hashtags: string[];
  bestPostTime: string;
  targetAudience: string;
}

export interface ResearchResults {
  trendAnalysis: any[];
  competitorData: any[];
  monetizationOpportunities: any[];
  audienceInsights: any[];
}

export async function analyzeVideoTranscript(transcript: string): Promise<HighlightDetection[]> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are an expert at identifying viral moments in video content. Analyze the transcript and identify the most engaging segments that would perform well on social media platforms like TikTok, Instagram Reels, and YouTube Shorts. Return your analysis as JSON."
        },
        {
          role: "user",
          content: `Analyze this video transcript and identify the top 5 viral moments. For each moment, provide the timestamp (in seconds), duration, description, viral potential (0-1), and confidence (0-1): ${transcript}`
        }
      ],
      response_format: { type: "json_object" }
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    return result.highlights || [];
  } catch (error) {
    console.error("Error analyzing video transcript:", error);
    throw new Error("Failed to analyze video content");
  }
}

export async function generateViralScore(content: string, metadata: any): Promise<ViralAnalysis> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are a social media expert who can predict viral potential. Analyze content and provide a viral score from 0-100 with detailed analysis. Return as JSON."
        },
        {
          role: "user",
          content: `Analyze this content for viral potential: ${content}. Metadata: ${JSON.stringify(metadata)}`
        }
      ],
      response_format: { type: "json_object" }
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    return {
      score: result.score || 0,
      factors: result.factors || [],
      recommendations: result.recommendations || [],
      confidence: result.confidence || 0
    };
  } catch (error) {
    console.error("Error generating viral score:", error);
    throw new Error("Failed to generate viral analysis");
  }
}

export async function generateContentStrategy(topic: string, platform: string): Promise<ContentStrategy> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are a content strategist specializing in social media monetization. Create comprehensive content strategies optimized for specific platforms. Return as JSON."
        },
        {
          role: "user",
          content: `Create a content strategy for "${topic}" on ${platform}. Include title, description, hashtags, best posting time, and target audience.`
        }
      ],
      response_format: { type: "json_object" }
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    return {
      title: result.title || "",
      description: result.description || "",
      hashtags: result.hashtags || [],
      bestPostTime: result.bestPostTime || "",
      targetAudience: result.targetAudience || ""
    };
  } catch (error) {
    console.error("Error generating content strategy:", error);
    throw new Error("Failed to generate content strategy");
  }
}

export async function conductAIResearch(query: string, type: string): Promise<ResearchResults> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are an ultra-intelligent AI research assistant specialized in social media monetization, trend analysis, and competitive intelligence. Provide comprehensive, actionable insights. Return as JSON."
        },
        {
          role: "user",
          content: `Conduct ${type} research on: "${query}". Provide trend analysis, competitor data, monetization opportunities, and audience insights.`
        }
      ],
      response_format: { type: "json_object" }
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    return {
      trendAnalysis: result.trendAnalysis || [],
      competitorData: result.competitorData || [],
      monetizationOpportunities: result.monetizationOpportunities || [],
      audienceInsights: result.audienceInsights || []
    };
  } catch (error) {
    console.error("Error conducting AI research:", error);
    throw new Error("Failed to conduct research");
  }
}

export async function generateSubtitles(transcript: string): Promise<{ text: string; startTime: number; endTime: number }[]> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "Convert transcript into timed subtitle segments optimized for social media. Each segment should be 3-5 words for maximum readability. Return as JSON."
        },
        {
          role: "user",
          content: `Generate subtitle segments from this transcript: ${transcript}`
        }
      ],
      response_format: { type: "json_object" }
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    return result.subtitles || [];
  } catch (error) {
    console.error("Error generating subtitles:", error);
    throw new Error("Failed to generate subtitles");
  }
}

export async function generateTextToVideo(prompt: string): Promise<{ scenes: any[]; narration: string; effects: string[] }> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are a professional video producer. Create detailed video production plans from text prompts, including scene descriptions, narration scripts, and visual effects. Return as JSON."
        },
        {
          role: "user",
          content: `Create a complete video production plan for: "${prompt}". Include detailed scenes, narration script, and suggested effects.`
        }
      ],
      response_format: { type: "json_object" }
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    return {
      scenes: result.scenes || [],
      narration: result.narration || "",
      effects: result.effects || []
    };
  } catch (error) {
    console.error("Error generating text-to-video plan:", error);
    throw new Error("Failed to generate video plan");
  }
}
