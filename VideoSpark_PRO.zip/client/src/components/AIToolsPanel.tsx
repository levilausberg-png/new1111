import { useState } from "react";
import { Brain, Captions, Wand2, Volume2, Crop, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import ViralScoreCard from "./ViralScoreCard";
import { useToast } from "@/hooks/use-toast";

export default function AIToolsPanel() {
  const [processing, setProcessing] = useState<string | null>(null);
  const { toast } = useToast();

  const handleAITool = async (toolName: string, action: string) => {
    setProcessing(toolName);
    
    try {
      // Simulate AI processing
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      toast({
        title: "AI Processing Complete",
        description: `${toolName} analysis finished successfully.`,
      });
    } catch (error) {
      toast({
        title: "Processing Failed",
        description: `Failed to process ${toolName}. Please try again.`,
        variant: "destructive",
      });
    } finally {
      setProcessing(null);
    }
  };

  return (
    <div className="flex-1 p-4 overflow-y-auto">
      <h3 className="text-sm font-semibold text-gray-300 mb-3">AI Tools</h3>
      
      <div className="space-y-3">
        <Button
          className="w-full p-3 gradient-accent hover:opacity-90 rounded-lg text-left transition-all duration-200 justify-start"
          onClick={() => handleAITool("Auto Highlight Detection", "analyzeContent")}
          disabled={processing === "Auto Highlight Detection"}
        >
          <div className="flex items-center space-x-3">
            {processing === "Auto Highlight Detection" ? (
              <Loader2 className="w-5 h-5 animate-spin" />
            ) : (
              <Brain className="w-5 h-5" />
            )}
            <div>
              <p className="font-medium">Auto Highlight Detection</p>
              <p className="text-xs text-purple-200">Find viral moments</p>
            </div>
          </div>
        </Button>

        <Button
          variant="ghost"
          className="w-full p-3 videospark-primary-700 hover:videospark-primary-600 rounded-lg text-left transition-colors justify-start"
          onClick={() => handleAITool("Auto Subtitles", "generateSubtitles")}
          disabled={processing === "Auto Subtitles"}
        >
          <div className="flex items-center space-x-3">
            {processing === "Auto Subtitles" ? (
              <Loader2 className="w-5 h-5 animate-spin" />
            ) : (
              <Captions className="videospark-electric-500 w-5 h-5" />
            )}
            <div>
              <p className="font-medium">Auto Subtitles</p>
              <p className="text-xs text-gray-400">AI-generated captions</p>
            </div>
          </div>
        </Button>

        <Button
          variant="ghost"
          className="w-full p-3 videospark-primary-700 hover:videospark-primary-600 rounded-lg text-left transition-colors justify-start"
          onClick={() => handleAITool("Smart B-Roll", "generateBRoll")}
          disabled={processing === "Smart B-Roll"}
        >
          <div className="flex items-center space-x-3">
            {processing === "Smart B-Roll" ? (
              <Loader2 className="w-5 h-5 animate-spin" />
            ) : (
              <Wand2 className="text-yellow-500 w-5 h-5" />
            )}
            <div>
              <p className="font-medium">Smart B-Roll</p>
              <p className="text-xs text-gray-400">Enhance with visuals</p>
            </div>
          </div>
        </Button>

        <Button
          variant="ghost"
          className="w-full p-3 videospark-primary-700 hover:videospark-primary-600 rounded-lg text-left transition-colors justify-start"
          onClick={() => handleAITool("Audio Enhancement", "enhanceAudio")}
          disabled={processing === "Audio Enhancement"}
        >
          <div className="flex items-center space-x-3">
            {processing === "Audio Enhancement" ? (
              <Loader2 className="w-5 h-5 animate-spin" />
            ) : (
              <Volume2 className="text-green-500 w-5 h-5" />
            )}
            <div>
              <p className="font-medium">Audio Enhancement</p>
              <p className="text-xs text-gray-400">Noise reduction & clarity</p>
            </div>
          </div>
        </Button>

        <Button
          variant="ghost"
          className="w-full p-3 videospark-primary-700 hover:videospark-primary-600 rounded-lg text-left transition-colors justify-start"
          onClick={() => handleAITool("Auto Reframe", "autoReframe")}
          disabled={processing === "Auto Reframe"}
        >
          <div className="flex items-center space-x-3">
            {processing === "Auto Reframe" ? (
              <Loader2 className="w-5 h-5 animate-spin" />
            ) : (
              <Crop className="text-blue-500 w-5 h-5" />
            )}
            <div>
              <p className="font-medium">Auto Reframe</p>
              <p className="text-xs text-gray-400">Perfect for all platforms</p>
            </div>
          </div>
        </Button>
      </div>

      <ViralScoreCard score={87} />
    </div>
  );
}
