import { useState } from "react";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";

export default function PropertiesPanel() {
  const [platform, setPlatform] = useState("tiktok");
  const [duration, setDuration] = useState("30");
  const [durationUnit, setDurationUnit] = useState("seconds");
  const [styleTemplate, setStyleTemplate] = useState("viral-gaming");

  return (
    <div className="p-4 videospark-border border-b">
      <h3 className="text-sm font-semibold text-gray-300 mb-3">Properties</h3>
      
      <div className="space-y-4">
        <div>
          <Label className="block text-xs text-gray-400 mb-2">Platform</Label>
          <Select value={platform} onValueChange={setPlatform}>
            <SelectTrigger className="w-full videospark-primary-700 videospark-border border-gray-600 text-sm focus:border-purple-500">
              <SelectValue />
            </SelectTrigger>
            <SelectContent className="videospark-primary-700 videospark-border border-gray-600">
              <SelectItem value="tiktok">TikTok (9:16)</SelectItem>
              <SelectItem value="instagram">Instagram Reel (9:16)</SelectItem>
              <SelectItem value="youtube-shorts">YouTube Shorts (9:16)</SelectItem>
              <SelectItem value="youtube">YouTube (16:9)</SelectItem>
              <SelectItem value="custom">Custom</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div>
          <Label className="block text-xs text-gray-400 mb-2">Clip Duration</Label>
          <div className="flex space-x-2">
            <Input
              type="number"
              value={duration}
              onChange={(e) => setDuration(e.target.value)}
              className="flex-1 videospark-primary-700 videospark-border border-gray-600 text-sm focus:border-purple-500"
            />
            <Select value={durationUnit} onValueChange={setDurationUnit}>
              <SelectTrigger className="videospark-primary-700 videospark-border border-gray-600 text-sm focus:border-purple-500">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="videospark-primary-700 videospark-border border-gray-600">
                <SelectItem value="seconds">seconds</SelectItem>
                <SelectItem value="minutes">minutes</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div>
          <Label className="block text-xs text-gray-400 mb-2">Style Template</Label>
          <Select value={styleTemplate} onValueChange={setStyleTemplate}>
            <SelectTrigger className="w-full videospark-primary-700 videospark-border border-gray-600 text-sm focus:border-purple-500">
              <SelectValue />
            </SelectTrigger>
            <SelectContent className="videospark-primary-700 videospark-border border-gray-600">
              <SelectItem value="viral-gaming">Viral Gaming</SelectItem>
              <SelectItem value="educational">Educational</SelectItem>
              <SelectItem value="dramatic">Dramatic</SelectItem>
              <SelectItem value="minimal">Minimal</SelectItem>
              <SelectItem value="custom">Custom</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
    </div>
  );
}
