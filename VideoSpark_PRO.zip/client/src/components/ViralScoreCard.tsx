import { Flame } from "lucide-react";

interface ViralScoreCardProps {
  score: number;
}

export default function ViralScoreCard({ score }: ViralScoreCardProps) {
  const getScoreColor = (score: number) => {
    if (score >= 80) return "text-green-400";
    if (score >= 60) return "text-yellow-400";
    return "text-red-400";
  };

  const getBarColor = (score: number) => {
    if (score >= 80) return "bg-green-400";
    if (score >= 60) return "bg-yellow-400";
    return "bg-red-400";
  };

  return (
    <div className="mt-6 p-4 bg-gradient-to-br from-green-900/50 to-green-800/50 border border-green-700 rounded-lg">
      <div className="flex items-center justify-between mb-2">
        <h4 className="text-sm font-semibold">Viral Score</h4>
        <div className="flex items-center space-x-1">
          <Flame className="text-orange-400 w-4 h-4" />
          <span className={`text-lg font-bold ${getScoreColor(score)}`}>{score}%</span>
        </div>
      </div>
      <p className="text-xs text-green-300">High engagement potential detected!</p>
      <div className="mt-2 bg-green-800 rounded-full h-2">
        <div 
          className={`h-2 rounded-full ${getBarColor(score)}`} 
          style={{ width: `${score}%` }}
        />
      </div>
    </div>
  );
}
