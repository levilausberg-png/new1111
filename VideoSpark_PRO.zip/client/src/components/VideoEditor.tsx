import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Slider } from "@/components/ui/slider";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  Play, 
  Pause, 
  SkipBack, 
  SkipForward, 
  Scissors, 
  Wand2, 
  Volume2, 
  VolumeX, 
  Download,
  Upload,
  Eye,
  Sparkles,
  Zap,
  Target,
  TrendingUp,
  Clock,
  Type,
  Image as ImageIcon,
  Music,
  Palette
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

interface VideoEditorProps {
  projectId: string;
  videoId?: string;
  onClose?: () => void;
}

interface ClipSegment {
  id: string;
  startTime: number;
  endTime: number;
  title: string;
  viralPotential: number;
  type: "highlight" | "hook" | "transition" | "outro";
}

interface AIInsight {
  type: "viral_moment" | "engagement_peak" | "silence_removal" | "caption_suggestion";
  timestamp: number;
  confidence: number;
  description: string;
  action?: string;
}

export default function VideoEditor({ projectId, videoId, onClose }: VideoEditorProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const videoRef = useRef<HTMLVideoElement>(null);
  
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(1);
  const [selectedSegment, setSelectedSegment] = useState<ClipSegment | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  
  // AI-powered clip suggestions
  const [aiInsights, setAiInsights] = useState<AIInsight[]>([]);
  const [clipSuggestions, setClipSuggestions] = useState<ClipSegment[]>([]);
  
  // Fetch project and video data
  const { data: project } = useQuery({
    queryKey: ["/api/projects", projectId],
  });
  
  const { data: video } = useQuery({
    queryKey: ["/api/videos", videoId],
    enabled: !!videoId,
  });
  
  // AI Analysis mutation
  const analyzeVideoMutation = useMutation({
    mutationFn: async (videoData: { videoId: string; analysisType: string }) => {
      return apiRequest("/api/ai/analyze-video", {
        method: "POST",
        body: JSON.stringify(videoData),
        headers: { "Content-Type": "application/json" },
      });
    },
    onSuccess: (data) => {
      setAiInsights(data.insights || []);
      setClipSuggestions(data.clipSuggestions || []);
      toast({
        title: "AI Analysis Complete",
        description: `Found ${data.insights?.length || 0} optimization opportunities and ${data.clipSuggestions?.length || 0} viral clip suggestions`,
      });
    },
    onError: () => {
      toast({
        title: "Analysis Failed",
        description: "Could not analyze video content. Please try again.",
        variant: "destructive",
      });
    },
  });
  
  // Generate clip mutation
  const generateClipMutation = useMutation({
    mutationFn: async (clipData: { 
      projectId: string; 
      videoId: string; 
      startTime: number; 
      endTime: number; 
      title: string;
      effects?: string[];
    }) => {
      return apiRequest("/api/clips/generate", {
        method: "POST",
        body: JSON.stringify(clipData),
        headers: { "Content-Type": "application/json" },
      });
    },
    onSuccess: (data) => {
      toast({
        title: "Clip Generated Successfully",
        description: `Your ${data.duration}s clip is ready for optimization and publishing`,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/clips"] });
    },
    onError: () => {
      toast({
        title: "Clip Generation Failed",
        description: "Could not generate clip. Please check your selection and try again.",
        variant: "destructive",
      });
    },
  });
  
  // Video player controls
  const togglePlayPause = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
      } else {
        videoRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };
  
  const seekTo = (time: number) => {
    if (videoRef.current) {
      videoRef.current.currentTime = time;
      setCurrentTime(time);
    }
  };
  
  const handleTimeUpdate = () => {
    if (videoRef.current) {
      setCurrentTime(videoRef.current.currentTime);
    }
  };
  
  const handleLoadedMetadata = () => {
    if (videoRef.current) {
      setDuration(videoRef.current.duration);
    }
  };
  
  // AI-powered analysis
  const runAIAnalysis = () => {
    if (!videoId) return;
    
    setIsProcessing(true);
    analyzeVideoMutation.mutate({ 
      videoId, 
      analysisType: "comprehensive" 
    });
    
    setTimeout(() => setIsProcessing(false), 3000);
  };
  
  // Generate clip from selection
  const generateClip = (segment: ClipSegment) => {
    if (!videoId) return;
    
    generateClipMutation.mutate({
      projectId,
      videoId,
      startTime: segment.startTime,
      endTime: segment.endTime,
      title: segment.title,
      effects: ["auto_captions", "viral_optimization", "audio_enhancement"]
    });
  };
  
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };
  
  const getViralScoreColor = (score: number) => {
    if (score >= 80) return "bg-green-500";
    if (score >= 60) return "bg-yellow-500";
    return "bg-red-500";
  };
  
  return (
    <div className="flex h-screen bg-background">
      {/* Main Video Panel */}
      <div className="flex-1 flex flex-col">
        {/* Video Player */}
        <div className="flex-1 bg-black relative">
          {video?.filePath ? (
            <video
              ref={videoRef}
              className="w-full h-full object-contain"
              src={video.filePath}
              onTimeUpdate={handleTimeUpdate}
              onLoadedMetadata={handleLoadedMetadata}
              onPlay={() => setIsPlaying(true)}
              onPause={() => setIsPlaying(false)}
            />
          ) : (
            <div className="flex items-center justify-center h-full text-muted-foreground">
              <div className="text-center">
                <Upload className="h-16 w-16 mx-auto mb-4" />
                <p className="text-xl mb-2">Upload a video to start editing</p>
                <p className="text-sm">Drag and drop or click to select</p>
              </div>
            </div>
          )}
          
          {/* Video Overlay Controls */}
          <div className="absolute bottom-4 left-4 right-4">
            {/* Progress Bar */}
            <div className="mb-4">
              <Slider
                value={[currentTime]}
                max={duration || 100}
                step={0.1}
                onValueChange={([value]) => seekTo(value)}
                className="w-full"
              />
              <div className="flex justify-between text-xs text-white mt-1">
                <span>{formatTime(currentTime)}</span>
                <span>{formatTime(duration)}</span>
              </div>
            </div>
            
            {/* Player Controls */}
            <div className="flex items-center justify-center space-x-4 bg-black/50 rounded-lg p-3">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => seekTo(Math.max(0, currentTime - 10))}
                className="text-white hover:bg-white/20"
              >
                <SkipBack className="h-4 w-4" />
              </Button>
              
              <Button
                variant="ghost"
                size="lg"
                onClick={togglePlayPause}
                className="text-white hover:bg-white/20"
              >
                {isPlaying ? <Pause className="h-6 w-6" /> : <Play className="h-6 w-6" />}
              </Button>
              
              <Button
                variant="ghost"
                size="sm"
                onClick={() => seekTo(Math.min(duration, currentTime + 10))}
                className="text-white hover:bg-white/20"
              >
                <SkipForward className="h-4 w-4" />
              </Button>
              
              <div className="flex items-center space-x-2">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setVolume(volume > 0 ? 0 : 1)}
                  className="text-white hover:bg-white/20"
                >
                  {volume > 0 ? <Volume2 className="h-4 w-4" /> : <VolumeX className="h-4 w-4" />}
                </Button>
                <Slider
                  value={[volume]}
                  max={1}
                  step={0.1}
                  onValueChange={([value]) => setVolume(value)}
                  className="w-20"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Right Panel - AI Tools & Timeline */}
      <div className="w-96 border-l bg-background flex flex-col">
        <Tabs defaultValue="ai-tools" className="flex-1">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="ai-tools">AI Tools</TabsTrigger>
            <TabsTrigger value="clips">Clips</TabsTrigger>
            <TabsTrigger value="effects">Effects</TabsTrigger>
          </TabsList>
          
          <TabsContent value="ai-tools" className="flex-1">
            <ScrollArea className="h-full px-4">
              <div className="space-y-4">
                {/* AI Analysis Card */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <Sparkles className="h-5 w-5 text-purple-500" />
                      <span>AI Video Analysis</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <Button
                      onClick={runAIAnalysis}
                      disabled={!videoId || isProcessing}
                      className="w-full"
                    >
                      {isProcessing ? (
                        <>
                          <Wand2 className="h-4 w-4 mr-2 animate-spin" />
                          Analyzing...
                        </>
                      ) : (
                        <>
                          <Zap className="h-4 w-4 mr-2" />
                          Run GOD MODE Analysis
                        </>
                      )}
                    </Button>
                    
                    {aiInsights.length > 0 && (
                      <div className="space-y-2">
                        <Label className="text-sm font-medium">AI Insights</Label>
                        {aiInsights.map((insight, index) => (
                          <div key={index} className="p-3 rounded-lg bg-muted">
                            <div className="flex items-center justify-between mb-1">
                              <Badge variant="secondary" className="text-xs">
                                {insight.type.replace('_', ' ')}
                              </Badge>
                              <span className="text-xs text-muted-foreground">
                                {formatTime(insight.timestamp)}
                              </span>
                            </div>
                            <p className="text-sm">{insight.description}</p>
                            {insight.action && (
                              <Button size="sm" className="mt-2">
                                {insight.action}
                              </Button>
                            )}
                          </div>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
                
                {/* Viral Clip Suggestions */}
                {clipSuggestions.length > 0 && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center space-x-2">
                        <TrendingUp className="h-5 w-5 text-green-500" />
                        <span>Viral Clip Suggestions</span>
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      {clipSuggestions.map((clip) => (
                        <div key={clip.id} className="p-3 rounded-lg border">
                          <div className="flex items-center justify-between mb-2">
                            <h4 className="font-medium text-sm">{clip.title}</h4>
                            <div className="flex items-center space-x-1">
                              <div className={`w-2 h-2 rounded-full ${getViralScoreColor(clip.viralPotential)}`} />
                              <span className="text-xs">{clip.viralPotential}%</span>
                            </div>
                          </div>
                          <div className="flex items-center justify-between text-xs text-muted-foreground mb-2">
                            <span>{formatTime(clip.startTime)} - {formatTime(clip.endTime)}</span>
                            <Badge variant="outline" className="text-xs">
                              {clip.type}
                            </Badge>
                          </div>
                          <Button
                            size="sm"
                            onClick={() => generateClip(clip)}
                            disabled={generateClipMutation.isPending}
                            className="w-full"
                          >
                            <Scissors className="h-3 w-3 mr-1" />
                            Generate Clip
                          </Button>
                        </div>
                      ))}
                    </CardContent>
                  </Card>
                )}
                
                {/* Quick Actions */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <Wand2 className="h-5 w-5 text-blue-500" />
                      <span>Smart Edits</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    <Button variant="outline" className="w-full justify-start">
                      <Type className="h-4 w-4 mr-2" />
                      Auto Generate Captions
                    </Button>
                    <Button variant="outline" className="w-full justify-start">
                      <VolumeX className="h-4 w-4 mr-2" />
                      Remove Silence
                    </Button>
                    <Button variant="outline" className="w-full justify-start">
                      <Eye className="h-4 w-4 mr-2" />
                      Detect Highlights
                    </Button>
                    <Button variant="outline" className="w-full justify-start">
                      <ImageIcon className="h-4 w-4 mr-2" />
                      Add B-Roll
                    </Button>
                    <Button variant="outline" className="w-full justify-start">
                      <Music className="h-4 w-4 mr-2" />
                      Background Music
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </ScrollArea>
          </TabsContent>
          
          <TabsContent value="clips" className="flex-1">
            <ScrollArea className="h-full px-4">
              <div className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Generated Clips</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground">
                      Clips will appear here after generation
                    </p>
                  </CardContent>
                </Card>
              </div>
            </ScrollArea>
          </TabsContent>
          
          <TabsContent value="effects" className="flex-1">
            <ScrollArea className="h-full px-4">
              <div className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <Palette className="h-5 w-5" />
                      <span>Visual Effects</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    <Button variant="outline" className="w-full justify-start">
                      Zoom & Pan
                    </Button>
                    <Button variant="outline" className="w-full justify-start">
                      Color Grading
                    </Button>
                    <Button variant="outline" className="w-full justify-start">
                      Transitions
                    </Button>
                    <Button variant="outline" className="w-full justify-start">
                      Text Overlays
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </ScrollArea>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}