import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { 
  Search, 
  TrendingUp, 
  Zap, 
  Target, 
  Sparkles, 
  Brain, 
  BarChart3,
  DollarSign,
  Users,
  Video,
  Hash,
  Calendar,
  Clock,
  Star,
  Flame,
  Eye,
  Heart,
  Share,
  MessageCircle,
  Download,
  RefreshCw,
  Lightbulb,
  Trophy,
  Rocket,
  Globe,
  Filter
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

interface ResearchQuery {
  id: string;
  query: string;
  type: string;
  status: string;
  createdAt: string;
  results?: ResearchResults;
}

interface ResearchResults {
  trendingTopics: TrendingTopic[];
  viralHashtags: HashtagAnalysis[];
  competitorAnalysis: CompetitorData[];
  contentStrategy: ContentStrategy;
  monetizationOpportunities: MonetizationOpportunity[];
  platformInsights: PlatformInsight[];
}

interface TrendingTopic {
  topic: string;
  viralScore: number;
  engagement: number;
  difficulty: number;
  platforms: string[];
  suggestedContent: string[];
}

interface HashtagAnalysis {
  hashtag: string;
  volume: number;
  engagement: number;
  competition: number;
  trend: "rising" | "stable" | "declining";
  relatedTags: string[];
}

interface CompetitorData {
  username: string;
  platform: string;
  followers: number;
  avgViews: number;
  topContent: string[];
  strategy: string;
}

interface ContentStrategy {
  bestPostingTimes: PostingTime[];
  contentPillars: string[];
  viralFormulas: ViralFormula[];
  platformSpecific: PlatformStrategy[];
}

interface PostingTime {
  platform: string;
  day: string;
  timeRange: string;
  engagement: number;
}

interface ViralFormula {
  title: string;
  description: string;
  successRate: number;
  examples: string[];
}

interface MonetizationOpportunity {
  type: string;
  platform: string;
  potential: number;
  requirements: string[];
  timeline: string;
}

interface PlatformInsight {
  platform: string;
  algorithm: string;
  bestPractices: string[];
  currentTrends: string[];
}

interface PlatformStrategy {
  platform: string;
  format: string;
  duration: string;
  hooks: string[];
}

export default function ResearchHub() {
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  // Fetch research queries
  const { data: researchQueries = [], isLoading } = useQuery({
    queryKey: ["/api/research/queries"],
  });

  // AI Research mutation
  const researchMutation = useMutation({
    mutationFn: async (data: { query: string; type: string; platforms: string[] }) => {
      return apiRequest("/api/research/analyze", {
        method: "POST",
        body: JSON.stringify(data),
        headers: { "Content-Type": "application/json" },
      });
    },
    onSuccess: (data) => {
      toast({
        title: "GOD MODE Research Complete",
        description: `Discovered ${data.insights?.length || 0} monetization opportunities and viral strategies`,
      });
      setIsAnalyzing(false);
    },
    onError: () => {
      toast({
        title: "Research Failed",
        description: "Could not complete market analysis. Please try again.",
        variant: "destructive",
      });
      setIsAnalyzing(false);
    },
  });

  const runGodModeResearch = () => {
    if (!searchQuery.trim()) return;

    setIsAnalyzing(true);
    researchMutation.mutate({
      query: searchQuery,
      type: "comprehensive",
      platforms: ["tiktok", "instagram", "youtube"]
    });
  };

  const getViralScoreColor = (score: number) => {
    if (score >= 80) return "text-green-500";
    if (score >= 60) return "text-yellow-500";
    return "text-red-500";
  };

  const getTrendIcon = (trend: "rising" | "stable" | "declining") => {
    if (trend === "rising") return <TrendingUp className="h-4 w-4 text-green-500" />;
    if (trend === "stable") return <Target className="h-4 w-4 text-blue-500" />;
    return <Target className="h-4 w-4 text-red-500 rotate-180" />;
  };

  const formatNumber = (num: number) => {
    if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`;
    if (num >= 1000) return `${(num / 1000).toFixed(1)}K`;
    return num.toString();
  };

  // Mock data for demonstration (in real app, this would come from API)
  const mockResults: ResearchResults = {
    trendingTopics: [
      {
        topic: "AI Productivity Hacks",
        viralScore: 94,
        engagement: 850000,
        difficulty: 65,
        platforms: ["TikTok", "Instagram", "YouTube"],
        suggestedContent: ["ChatGPT workflow automation", "AI video editing tips", "Passive income with AI"]
      },
      {
        topic: "Minimalist Home Office",
        viralScore: 87,
        engagement: 620000,
        difficulty: 45,
        platforms: ["Instagram", "Pinterest", "YouTube"],
        suggestedContent: ["Desk setup transformation", "Cable management hacks", "Lighting optimization"]
      }
    ],
    viralHashtags: [
      {
        hashtag: "#ProductivityHack",
        volume: 2400000,
        engagement: 4.8,
        competition: 75,
        trend: "rising",
        relatedTags: ["#TimeManagement", "#WorkFromHome", "#LifeHacks"]
      },
      {
        hashtag: "#AITools",
        volume: 1800000,
        engagement: 6.2,
        competition: 85,
        trend: "rising",
        relatedTags: ["#Technology", "#Automation", "#FutureOfWork"]
      }
    ],
    competitorAnalysis: [
      {
        username: "@techoptimizer",
        platform: "TikTok",
        followers: 450000,
        avgViews: 85000,
        topContent: ["Morning routine with AI", "Productivity app reviews", "Work setup tours"],
        strategy: "Educational content with personality-driven delivery"
      }
    ],
    contentStrategy: {
      bestPostingTimes: [
        { platform: "TikTok", day: "Wednesday", timeRange: "6-9 PM", engagement: 4.2 },
        { platform: "Instagram", day: "Friday", timeRange: "11 AM-1 PM", engagement: 3.8 }
      ],
      contentPillars: ["Technology Reviews", "Productivity Tips", "Workspace Design", "AI Integration"],
      viralFormulas: [
        {
          title: "Problem-Solution Hook",
          description: "Start with a relatable problem, then reveal the solution",
          successRate: 89,
          examples: ["Struggling with productivity? Try this AI hack", "Messy desk? Here's a 5-minute fix"]
        }
      ],
      platformSpecific: [
        {
          platform: "TikTok",
          format: "Vertical Video",
          duration: "15-30 seconds",
          hooks: ["POV:", "This changed everything:", "Nobody talks about this:"]
        }
      ]
    },
    monetizationOpportunities: [
      {
        type: "Affiliate Marketing",
        platform: "All Platforms",
        potential: 5000,
        requirements: ["1K+ followers", "Consistent content", "Niche authority"],
        timeline: "2-3 months"
      },
      {
        type: "Course Creation",
        platform: "YouTube + Landing Page",
        potential: 15000,
        requirements: ["10K+ followers", "Proven expertise", "Email list"],
        timeline: "4-6 months"
      }
    ],
    platformInsights: [
      {
        platform: "TikTok",
        algorithm: "Engagement-first, then completion rate",
        bestPractices: ["Hook within 3 seconds", "Use trending sounds", "Post consistently"],
        currentTrends: ["Before/After transformations", "Educational carousels", "Aesthetic B-roll"]
      }
    ]
  };

  return (
    <div className="container mx-auto p-6 space-y-6">
      {/* Header */}
      <div className="text-center space-y-4">
        <div className="flex justify-center items-center space-x-2">
          <Brain className="h-8 w-8 text-purple-500" />
          <h1 className="text-3xl font-bold bg-gradient-to-r from-purple-500 to-blue-500 bg-clip-text text-transparent">
            AI Research Hub - GOD MODE
          </h1>
          <Zap className="h-8 w-8 text-yellow-500" />
        </div>
        <p className="text-muted-foreground max-w-2xl mx-auto">
          Ultra-intelligent social media monetization research with maximum optimization for viral content strategy and revenue generation
        </p>
      </div>

      {/* Search Section */}
      <Card className="border-purple-200 dark:border-purple-800">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Search className="h-5 w-5 text-purple-500" />
            <span>Market Intelligence Query</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex space-x-2">
            <Input
              placeholder="Enter niche, topic, or competitor to analyze (e.g., 'productivity apps', 'morning routines', '@username')"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="flex-1"
              onKeyPress={(e) => e.key === "Enter" && runGodModeResearch()}
            />
            <Button 
              onClick={runGodModeResearch}
              disabled={isAnalyzing || !searchQuery.trim()}
              className="bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600"
            >
              {isAnalyzing ? (
                <>
                  <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                  Analyzing...
                </>
              ) : (
                <>
                  <Rocket className="h-4 w-4 mr-2" />
                  GOD MODE
                </>
              )}
            </Button>
          </div>

          <div className="flex flex-wrap gap-2">
            <Badge variant="secondary" className="cursor-pointer">Trending Topics</Badge>
            <Badge variant="secondary" className="cursor-pointer">Competitor Analysis</Badge>
            <Badge variant="secondary" className="cursor-pointer">Hashtag Research</Badge>
            <Badge variant="secondary" className="cursor-pointer">Monetization Strategy</Badge>
            <Badge variant="secondary" className="cursor-pointer">Platform Optimization</Badge>
          </div>
        </CardContent>
      </Card>

      {/* Results Section */}
      <Tabs defaultValue="trending" className="space-y-4">
        <TabsList className="grid w-full grid-cols-6">
          <TabsTrigger value="trending">Trending</TabsTrigger>
          <TabsTrigger value="hashtags">Hashtags</TabsTrigger>
          <TabsTrigger value="competitors">Competitors</TabsTrigger>
          <TabsTrigger value="strategy">Strategy</TabsTrigger>
          <TabsTrigger value="monetization">Money</TabsTrigger>
          <TabsTrigger value="insights">Insights</TabsTrigger>
        </TabsList>

        <TabsContent value="trending" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            {mockResults.trendingTopics.map((topic, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg">{topic.topic}</CardTitle>
                    <div className="flex items-center space-x-1">
                      <Flame className="h-4 w-4 text-orange-500" />
                      <span className={`font-bold ${getViralScoreColor(topic.viralScore)}`}>
                        {topic.viralScore}%
                      </span>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-3 gap-4 text-center">
                    <div>
                      <div className="flex items-center justify-center space-x-1 text-blue-500">
                        <Eye className="h-4 w-4" />
                        <span className="text-sm font-medium">Engagement</span>
                      </div>
                      <p className="font-bold">{formatNumber(topic.engagement)}</p>
                    </div>
                    <div>
                      <div className="flex items-center justify-center space-x-1 text-yellow-500">
                        <Target className="h-4 w-4" />
                        <span className="text-sm font-medium">Difficulty</span>
                      </div>
                      <p className="font-bold">{topic.difficulty}%</p>
                    </div>
                    <div>
                      <div className="flex items-center justify-center space-x-1 text-green-500">
                        <Globe className="h-4 w-4" />
                        <span className="text-sm font-medium">Platforms</span>
                      </div>
                      <p className="font-bold">{topic.platforms.length}</p>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label className="text-sm font-medium">Content Ideas</Label>
                    <div className="flex flex-wrap gap-2">
                      {topic.suggestedContent.map((content, idx) => (
                        <Badge key={idx} variant="outline" className="text-xs">
                          {content}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <div className="flex space-x-2">
                    <Button size="sm" className="flex-1">
                      <Video className="h-3 w-3 mr-1" />
                      Create Content
                    </Button>
                    <Button size="sm" variant="outline">
                      <Lightbulb className="h-3 w-3 mr-1" />
                      Get Ideas
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="hashtags" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {mockResults.viralHashtags.map((hashtag, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg flex items-center space-x-2">
                      <Hash className="h-4 w-4 text-blue-500" />
                      <span>{hashtag.hashtag.substring(1)}</span>
                    </CardTitle>
                    {getTrendIcon(hashtag.trend)}
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="grid grid-cols-2 gap-3 text-sm">
                    <div>
                      <Label className="text-muted-foreground">Volume</Label>
                      <p className="font-bold">{formatNumber(hashtag.volume)}</p>
                    </div>
                    <div>
                      <Label className="text-muted-foreground">Engagement</Label>
                      <p className="font-bold text-green-500">{hashtag.engagement}%</p>
                    </div>
                    <div>
                      <Label className="text-muted-foreground">Competition</Label>
                      <p className="font-bold text-orange-500">{hashtag.competition}%</p>
                    </div>
                    <div>
                      <Label className="text-muted-foreground">Trend</Label>
                      <p className="font-bold capitalize">{hashtag.trend}</p>
                    </div>
                  </div>

                  <div>
                    <Label className="text-sm font-medium">Related Tags</Label>
                    <div className="flex flex-wrap gap-1 mt-1">
                      {hashtag.relatedTags.map((tag, idx) => (
                        <Badge key={idx} variant="secondary" className="text-xs">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <Button size="sm" className="w-full">
                    <Download className="h-3 w-3 mr-1" />
                    Use This Tag
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="competitors" className="space-y-4">
          <div className="grid gap-4">
            {mockResults.competitorAnalysis.map((competitor, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="flex items-center space-x-2">
                      <Users className="h-5 w-5 text-blue-500" />
                      <span>{competitor.username}</span>
                      <Badge variant="secondary">{competitor.platform}</Badge>
                    </CardTitle>
                    <Trophy className="h-5 w-5 text-yellow-500" />
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="text-center">
                      <Label className="text-muted-foreground">Followers</Label>
                      <p className="text-2xl font-bold text-blue-500">
                        {formatNumber(competitor.followers)}
                      </p>
                    </div>
                    <div className="text-center">
                      <Label className="text-muted-foreground">Avg Views</Label>
                      <p className="text-2xl font-bold text-green-500">
                        {formatNumber(competitor.avgViews)}
                      </p>
                    </div>
                  </div>

                  <div>
                    <Label className="text-sm font-medium">Top Content Types</Label>
                    <div className="flex flex-wrap gap-2 mt-2">
                      {competitor.topContent.map((content, idx) => (
                        <Badge key={idx} variant="outline">
                          {content}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <div>
                    <Label className="text-sm font-medium">Strategy Analysis</Label>
                    <p className="text-sm text-muted-foreground mt-1">
                      {competitor.strategy}
                    </p>
                  </div>

                  <div className="flex space-x-2">
                    <Button size="sm" variant="outline" className="flex-1">
                      <Eye className="h-3 w-3 mr-1" />
                      Analyze Content
                    </Button>
                    <Button size="sm" className="flex-1">
                      <Target className="h-3 w-3 mr-1" />
                      Copy Strategy
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="strategy" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            {/* Posting Times */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Clock className="h-5 w-5 text-green-500" />
                  <span>Optimal Posting Times</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {mockResults.contentStrategy.bestPostingTimes.map((time, index) => (
                    <div key={index} className="flex items-center justify-between p-3 rounded-lg bg-muted">
                      <div>
                        <p className="font-medium">{time.platform}</p>
                        <p className="text-sm text-muted-foreground">
                          {time.day} • {time.timeRange}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="font-bold text-green-500">{time.engagement}%</p>
                        <p className="text-xs text-muted-foreground">engagement</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Viral Formulas */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Star className="h-5 w-5 text-yellow-500" />
                  <span>Viral Formulas</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {mockResults.contentStrategy.viralFormulas.map((formula, index) => (
                    <div key={index} className="p-3 rounded-lg border">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-medium">{formula.title}</h4>
                        <Badge variant="secondary">{formula.successRate}%</Badge>
                      </div>
                      <p className="text-sm text-muted-foreground mb-2">
                        {formula.description}
                      </p>
                      <div className="flex flex-wrap gap-1">
                        {formula.examples.map((example, idx) => (
                          <Badge key={idx} variant="outline" className="text-xs">
                            {example}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="monetization" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            {mockResults.monetizationOpportunities.map((opportunity, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow border-green-200 dark:border-green-800">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="flex items-center space-x-2">
                      <DollarSign className="h-5 w-5 text-green-500" />
                      <span>{opportunity.type}</span>
                    </CardTitle>
                    <Badge className="bg-green-500">{opportunity.platform}</Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="text-center">
                    <Label className="text-muted-foreground">Monthly Potential</Label>
                    <p className="text-3xl font-bold text-green-500">
                      ${formatNumber(opportunity.potential)}
                    </p>
                  </div>

                  <div>
                    <Label className="text-sm font-medium">Requirements</Label>
                    <ul className="text-sm text-muted-foreground mt-1 space-y-1">
                      {opportunity.requirements.map((req, idx) => (
                        <li key={idx} className="flex items-center space-x-2">
                          <div className="w-1 h-1 bg-green-500 rounded-full" />
                          <span>{req}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <Label className="text-sm font-medium">Timeline</Label>
                      <p className="text-sm text-muted-foreground">{opportunity.timeline}</p>
                    </div>
                    <Button size="sm" className="bg-green-500 hover:bg-green-600">
                      <Rocket className="h-3 w-3 mr-1" />
                      Start Now
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="insights" className="space-y-4">
          <div className="grid gap-4">
            {mockResults.platformInsights.map((insight, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <BarChart3 className="h-5 w-5 text-purple-500" />
                    <span>{insight.platform} Algorithm Insights</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label className="text-sm font-medium">Algorithm Focus</Label>
                    <p className="text-sm text-muted-foreground mt-1">{insight.algorithm}</p>
                  </div>

                  <div>
                    <Label className="text-sm font-medium">Best Practices</Label>
                    <ul className="text-sm text-muted-foreground mt-1 space-y-1">
                      {insight.bestPractices.map((practice, idx) => (
                        <li key={idx} className="flex items-center space-x-2">
                          <div className="w-1 h-1 bg-purple-500 rounded-full" />
                          <span>{practice}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div>
                    <Label className="text-sm font-medium">Current Trends</Label>
                    <div className="flex flex-wrap gap-2 mt-2">
                      {insight.currentTrends.map((trend, idx) => (
                        <Badge key={idx} variant="secondary">
                          {trend}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}