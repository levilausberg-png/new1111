# Overview

VideoSpark PRO is a comprehensive AI-powered video editing and social media management platform designed for creating viral content. The application combines advanced video processing capabilities with artificial intelligence to automatically detect highlights, generate clips, analyze viral potential, and streamline social media posting across multiple platforms.

The system features a modern React-based frontend with a robust Express.js backend, leveraging PostgreSQL for data persistence and integrating with OpenAI services for AI-powered content analysis and generation.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React 18 with TypeScript using Vite for build tooling
- **UI Library**: Shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with custom VideoSpark PRO dark theme
- **State Management**: TanStack Query for server state and React hooks for local state
- **Routing**: Wouter for lightweight client-side routing
- **Form Handling**: React Hook Form with Zod validation

## Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **API Design**: RESTful API with structured route handlers
- **File Handling**: Multer for multipart form data and file uploads
- **Error Handling**: Centralized error middleware with structured error responses

## Data Storage Solutions
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Connection**: Neon serverless PostgreSQL with connection pooling
- **Schema Management**: Drizzle Kit for migrations and schema management
- **Session Storage**: PostgreSQL-based session store using connect-pg-simple

## Authentication and Authorization
- **Session Management**: Express sessions with PostgreSQL storage
- **User Model**: Standard user table with subscription tiers
- **Security**: Cookie-based authentication with CORS support

## AI Integration Services
- **OpenAI Integration**: GPT-4o model for content analysis and generation
- **Video Analysis**: AI-powered transcript analysis for highlight detection
- **Viral Score Generation**: Machine learning-based content performance prediction
- **Content Strategy**: AI-generated recommendations for optimal posting

## Video Processing Pipeline
- **Upload Handling**: Multipart form data processing with file validation
- **Processing Engine**: Custom video processor for format conversion and optimization
- **Clip Generation**: Automated clip creation based on AI-detected highlights
- **Subtitle Generation**: AI-powered automatic caption generation

## Content Management System
- **Project-Based Organization**: Hierarchical structure (Projects > Videos > Clips)
- **Multi-Platform Support**: TikTok, Instagram, YouTube Shorts optimization
- **Scheduling System**: Automated posting with platform-specific timing
- **Analytics Tracking**: Performance monitoring across all platforms

# External Dependencies

## Core Infrastructure
- **Database**: Neon PostgreSQL serverless database
- **File Storage**: Local file system (uploads directory)
- **Session Store**: PostgreSQL-based session management

## AI and Machine Learning
- **OpenAI API**: GPT-4o for content analysis, highlight detection, and strategy generation
- **Natural Language Processing**: Transcript analysis and content optimization

## Social Media APIs
- **TikTok API**: Content posting and analytics (OAuth2 integration planned)
- **Instagram Graph API**: Reel publishing and engagement metrics
- **YouTube Data API**: Shorts upload and performance tracking

## Development and Deployment
- **Replit Integration**: Development environment with live reload capabilities
- **Build System**: Vite for frontend bundling, esbuild for backend compilation
- **Development Tools**: TypeScript compiler, Drizzle Kit for database operations

## Third-Party UI Libraries
- **Radix UI**: Accessible component primitives for complex UI patterns
- **Tailwind CSS**: Utility-first CSS framework for responsive design
- **Lucide React**: Icon library for consistent iconography

## Utility Libraries
- **Date Handling**: date-fns for date manipulation and formatting
- **Class Management**: clsx and tailwind-merge for conditional styling
- **Validation**: Zod for runtime type checking and form validation