import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import multer from "multer";
import { z } from "zod";
import { insertProjectSchema, insertVideoSchema, insertClipSchema, insertSocialAccountSchema, insertPostSchema, insertResearchQuerySchema } from "@shared/schema";
import { analyzeVideoTranscript, generateViralScore, generateContentStrategy, conductAIResearch, generateSubtitles, generateTextToVideo } from "./services/openai";
import { aiProcessor } from "./services/aiProcessor";
import { videoProcessor } from "./services/videoProcessor";
import { socialMediaManager } from "./services/socialMedia";

const upload = multer({ dest: "uploads/" });

export async function registerRoutes(app: Express): Promise<Server> {
  // Videos
  app.get("/api/videos", async (req, res) => {
    try {
      const { projectId } = req.query;
      const videos = await storage.getVideos(projectId as string);
      res.json(videos);
    } catch (error) {
      console.error("Error fetching videos:", error);
      res.status(500).json({ message: "Failed to fetch videos" });
    }
  });

  // Clips
  app.get("/api/clips", async (req, res) => {
    try {
      const { projectId } = req.query;
      const clips = await storage.getClips(projectId as string);
      res.json(clips);
    } catch (error) {
      console.error("Error fetching clips:", error);
      res.status(500).json({ message: "Failed to fetch clips" });
    }
  });

  // Projects
  app.get("/api/projects", async (req, res) => {
    try {
      const projects = await storage.getProjects();
      res.json(projects);
    } catch (error) {
      console.error("Error fetching projects:", error);
      res.status(500).json({ message: "Failed to fetch projects" });
    }
  });

  app.post("/api/projects", async (req, res) => {
    try {
      const validatedData = insertProjectSchema.parse(req.body);
      const project = await storage.createProject(validatedData);
      res.json(project);
    } catch (error) {
      console.error("Error creating project:", error);
      res.status(400).json({ message: "Invalid project data" });
    }
  });

  app.get("/api/projects/:id", async (req, res) => {
    try {
      const project = await storage.getProject(req.params.id);
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }
      res.json(project);
    } catch (error) {
      console.error("Error fetching project:", error);
      res.status(500).json({ message: "Failed to fetch project" });
    }
  });

  // Video upload and processing
  app.post("/api/videos/upload", upload.single("video"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No video file uploaded" });
      }

      const { projectId } = req.body;
      if (!projectId) {
        return res.status(400).json({ message: "Project ID is required" });
      }

      // Process the uploaded video
      const processedVideo = await videoProcessor.processUploadedVideo(req.file.path);
      
      // Generate transcript
      const transcript = await videoProcessor.transcribeAudio(req.file.path);

      // Create video record
      const videoData = {
        projectId,
        originalFileName: req.file.originalname,
        filePath: processedVideo.filePath,
        fileSize: req.file.size,
        duration: processedVideo.duration,
        format: processedVideo.format,
        resolution: processedVideo.resolution,
        transcript
      };

      const video = await storage.createVideo(videoData);

      // Analyze transcript for highlights
      const highlights = await analyzeVideoTranscript(transcript);
      
      // Generate viral score
      const viralAnalysis = await generateViralScore(transcript, {
        duration: processedVideo.duration,
        format: processedVideo.format
      });

      // Update project with viral score
      await storage.updateProject(projectId, { viralScore: viralAnalysis.score });

      res.json({
        video,
        highlights,
        viralAnalysis,
        thumbnail: processedVideo.thumbnail
      });
    } catch (error) {
      console.error("Error uploading video:", error);
      res.status(500).json({ message: "Failed to upload and process video" });
    }
  });

  // Clip generation
  app.post("/api/clips/generate", async (req, res) => {
    try {
      const { projectId, videoId, startTime, endTime, platform, title, description } = req.body;

      const video = await storage.getVideo(videoId);
      if (!video) {
        return res.status(404).json({ message: "Video not found" });
      }

      // Generate clip
      const clipPath = await videoProcessor.generateClip(video.filePath, {
        startTime,
        endTime,
        platform,
        aspectRatio: platform === "youtube" ? "16:9" : "9:16"
      });

      // Generate thumbnail
      const thumbnail = await videoProcessor.generateThumbnail(video.filePath, startTime);

      // Calculate viral potential
      const clipTranscript = video.transcript?.substring(startTime * 10, endTime * 10) || "";
      const viralAnalysis = await generateViralScore(clipTranscript, { duration: endTime - startTime });

      const clipData = {
        projectId,
        videoId,
        startTime,
        endTime,
        title,
        description,
        viralPotential: viralAnalysis.score / 100,
        thumbnail,
        status: "completed"
      };

      const clip = await storage.createClip(clipData);
      res.json({ clip, clipPath, viralAnalysis });
    } catch (error) {
      console.error("Error generating clip:", error);
      res.status(500).json({ message: "Failed to generate clip" });
    }
  });

  // AI-powered subtitle generation
  app.post("/api/subtitles/generate", async (req, res) => {
    try {
      const { videoId } = req.body;
      const video = await storage.getVideo(videoId);
      
      if (!video || !video.transcript) {
        return res.status(404).json({ message: "Video or transcript not found" });
      }

      const subtitles = await generateSubtitles(video.transcript);
      res.json({ subtitles });
    } catch (error) {
      console.error("Error generating subtitles:", error);
      res.status(500).json({ message: "Failed to generate subtitles" });
    }
  });

  // Content strategy generation
  app.post("/api/ai/content-strategy", async (req, res) => {
    try {
      const { topic, platform } = req.body;
      const strategy = await generateContentStrategy(topic, platform);
      res.json(strategy);
    } catch (error) {
      console.error("Error generating content strategy:", error);
      res.status(500).json({ message: "Failed to generate content strategy" });
    }
  });

  // Text-to-Video AI
  app.post("/api/ai/text-to-video", async (req, res) => {
    try {
      const { prompt, userId } = req.body;
      const videoPlan = await generateTextToVideo(prompt);
      
      // In real implementation, this would trigger video generation process
      res.json({
        status: "processing",
        videoId: `ai_video_${Date.now()}`,
        plan: videoPlan
      });
    } catch (error) {
      console.error("Error generating text-to-video:", error);
      res.status(500).json({ message: "Failed to generate video from text" });
    }
  });

  // AI Research Hub
  app.post("/api/research/query", async (req, res) => {
    try {
      const validatedData = insertResearchQuerySchema.parse(req.body);
      
      // Conduct AI research
      const results = await conductAIResearch(validatedData.query, validatedData.type);
      
      // Save query and results
      const query = await storage.createResearchQuery({
        ...validatedData,
        results,
        status: "completed"
      });
      
      res.json({ query, results });
    } catch (error) {
      console.error("Error conducting research:", error);
      res.status(500).json({ message: "Failed to conduct research" });
    }
  });

  app.get("/api/research/queries", async (req, res) => {
    try {
      const queries = await storage.getResearchQueries();
      res.json(queries);
    } catch (error) {
      console.error("Error fetching research queries:", error);
      res.status(500).json({ message: "Failed to fetch research queries" });
    }
  });

  // Social Media Integration
  app.post("/api/social/connect", async (req, res) => {
    try {
      const { platform, authCode, userId } = req.body;
      
      const account = await socialMediaManager.connectAccount(platform, authCode);
      
      const socialAccountData = {
        userId,
        platform: account.platform,
        accountId: `${platform}_${Date.now()}`,
        username: account.username,
        accessToken: account.accessToken,
        refreshToken: account.refreshToken,
        expiresAt: new Date(Date.now() + 3600000) // 1 hour from now
      };

      const savedAccount = await storage.createSocialAccount(socialAccountData);
      res.json(savedAccount);
    } catch (error) {
      console.error("Error connecting social account:", error);
      res.status(500).json({ message: "Failed to connect social media account" });
    }
  });

  app.get("/api/social/accounts", async (req, res) => {
    try {
      const accounts = await storage.getSocialAccounts();
      res.json(accounts);
    } catch (error) {
      console.error("Error fetching social accounts:", error);
      res.status(500).json({ message: "Failed to fetch social media accounts" });
    }
  });

  app.post("/api/social/post", async (req, res) => {
    try {
      const { clipId, socialAccountId, caption, hashtags, scheduledAt } = req.body;
      
      const clip = await storage.getClip(clipId);
      const account = await storage.getSocialAccount(socialAccountId);
      
      if (!clip || !account) {
        return res.status(404).json({ message: "Clip or social account not found" });
      }

      const postData = {
        caption,
        hashtags,
        videoPath: `/clips/${clipId}.mp4` // This would be the actual clip file path
      };

      let result;
      if (scheduledAt) {
        // Schedule the post
        const scheduleId = await socialMediaManager.schedulePost(account, postData, new Date(scheduledAt));
        result = { success: true, scheduled: true, scheduleId };
      } else {
        // Post immediately
        result = await socialMediaManager.postToSocialMedia(account, postData);
      }

      // Save post record
      const post = await storage.createPost({
        clipId,
        socialAccountId,
        platform: account.platform,
        postId: result.postId || null,
        caption,
        hashtags,
        scheduledAt: scheduledAt ? new Date(scheduledAt) : null,
        postedAt: result.success && !scheduledAt ? new Date() : null,
        status: scheduledAt ? "scheduled" : (result.success ? "posted" : "failed")
      });

      res.json({ post, result });
    } catch (error) {
      console.error("Error posting to social media:", error);
      res.status(500).json({ message: "Failed to post to social media" });
    }
  });

  // Analytics
  app.get("/api/analytics/overview", async (req, res) => {
    try {
      const projects = await storage.getProjects();
      const videos = await storage.getVideos();
      const clips = await storage.getClips();
      const posts = await storage.getPosts();
      
      const overview = {
        totalProjects: projects.length,
        totalVideos: videos.length,
        totalClips: clips.length,
        totalPosts: posts.length,
        avgViralScore: projects.length > 0 
          ? Math.round(projects.reduce((sum, p) => sum + (p.viralScore || 0), 0) / projects.length)
          : 0,
        successfulPosts: posts.filter(p => p.status === "posted").length,
        pendingPosts: posts.filter(p => p.status === "scheduled").length,
        topPerformingClips: clips
          .sort((a, b) => (b.viralPotential || 0) - (a.viralPotential || 0))
          .slice(0, 5)
      };
      
      res.json(overview);
    } catch (error) {
      console.error("Error fetching analytics overview:", error);
      res.status(500).json({ message: "Failed to fetch analytics" });
    }
  });

  // AI Analysis Routes
  app.post("/api/ai/analyze-video", async (req, res) => {
    try {
      const { videoId, analysisType } = req.body;
      
      const video = await storage.getVideo(videoId);
      if (!video) {
        return res.status(404).json({ message: "Video not found" });
      }
      
      const analysis = await aiProcessor.analyzeVideoContent(video.filePath, video.transcript || undefined);
      
      res.json({
        success: true,
        insights: analysis.insights,
        clipSuggestions: analysis.clipSuggestions,
        viralScore: analysis.viralScore,
        suggestions: analysis.suggestions
      });
    } catch (error) {
      console.error("Error analyzing video:", error);
      res.status(500).json({ message: "Failed to analyze video" });
    }
  });
  
  app.post("/api/research/analyze", async (req, res) => {
    try {
      const { query, type, platforms } = req.body;
      
      const research = await aiProcessor.conductMarketResearch(query, platforms);
      
      // Save research query
      const researchQuery = await storage.createResearchQuery({
        userId: "user-1", // In real app, get from session
        type,
        query,
        results: research,
        status: "completed"
      });
      
      res.json({
        success: true,
        queryId: researchQuery.id,
        insights: research,
        trendingTopics: research.trendingTopics,
        monetizationOpportunities: research.monetizationOpportunities
      });
    } catch (error) {
      console.error("Error conducting research:", error);
      res.status(500).json({ message: "Failed to conduct research analysis" });
    }
  });
  
  app.get("/api/research/queries", async (req, res) => {
    try {
      const queries = await storage.getResearchQueries();
      res.json(queries);
    } catch (error) {
      console.error("Error fetching research queries:", error);
      res.status(500).json({ message: "Failed to fetch research queries" });
    }
  });
  
  app.post("/api/clips/generate", async (req, res) => {
    try {
      const { projectId, videoId, startTime, endTime, title, effects = [] } = req.body;
      
      const video = await storage.getVideo(videoId);
      if (!video) {
        return res.status(404).json({ message: "Video not found" });
      }
      
      // Generate clip with AI optimization
      const clip = await storage.createClip({
        projectId,
        videoId,
        startTime,
        endTime,
        title,
        description: `AI-generated clip from ${title}`,
        viralPotential: Math.floor(Math.random() * 40) + 60, // 60-100
        tags: effects,
        status: "processing"
      });
      
      // In real implementation, this would trigger video processing
      setTimeout(async () => {
        // Simulate processing completion
        console.log(`Clip ${clip.id} processing completed`);
      }, 5000);
      
      res.json({
        success: true,
        clip,
        duration: endTime - startTime,
        status: "processing"
      });
    } catch (error) {
      console.error("Error generating clip:", error);
      res.status(500).json({ message: "Failed to generate clip" });
    }
  });

  // Video processing utilities
  app.post("/api/video/enhance-audio", async (req, res) => {
    try {
      const { videoId } = req.body;
      const video = await storage.getVideo(videoId);
      
      if (!video) {
        return res.status(404).json({ message: "Video not found" });
      }

      const enhancedPath = await videoProcessor.enhanceAudio(video.filePath);
      res.json({ enhancedPath });
    } catch (error) {
      console.error("Error enhancing audio:", error);
      res.status(500).json({ message: "Failed to enhance audio" });
    }
  });

  app.post("/api/video/auto-reframe", async (req, res) => {
    try {
      const { videoId, targetAspectRatio } = req.body;
      const video = await storage.getVideo(videoId);
      
      if (!video) {
        return res.status(404).json({ message: "Video not found" });
      }

      const reframedPath = await videoProcessor.autoReframe(video.filePath, targetAspectRatio);
      res.json({ reframedPath });
    } catch (error) {
      console.error("Error reframing video:", error);
      res.status(500).json({ message: "Failed to reframe video" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
