import { type User, type InsertUser, type Project, type InsertProject, type Video, type InsertVideo, type Clip, type InsertClip, type SocialAccount, type InsertSocialAccount, type Post, type InsertPost, type ResearchQuery, type InsertResearchQuery } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Project operations
  getProjects(): Promise<Project[]>;
  getProject(id: string): Promise<Project | undefined>;
  createProject(project: InsertProject): Promise<Project>;
  updateProject(id: string, updates: Partial<Project>): Promise<Project>;

  // Video operations
  getVideo(id: string): Promise<Video | undefined>;
  createVideo(video: InsertVideo): Promise<Video>;

  // Clip operations
  getClips(): Promise<Clip[]>;
  getClip(id: string): Promise<Clip | undefined>;
  createClip(clip: InsertClip): Promise<Clip>;

  // Social account operations
  getSocialAccounts(): Promise<SocialAccount[]>;
  getSocialAccount(id: string): Promise<SocialAccount | undefined>;
  createSocialAccount(account: InsertSocialAccount): Promise<SocialAccount>;

  // Post operations
  getPosts(): Promise<Post[]>;
  createPost(post: InsertPost): Promise<Post>;

  // Research operations
  getResearchQueries(): Promise<ResearchQuery[]>;
  createResearchQuery(query: InsertResearchQuery): Promise<ResearchQuery>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private projects: Map<string, Project>;
  private videos: Map<string, Video>;
  private clips: Map<string, Clip>;
  private socialAccounts: Map<string, SocialAccount>;
  private posts: Map<string, Post>;
  private researchQueries: Map<string, ResearchQuery>;

  constructor() {
    this.users = new Map();
    this.projects = new Map();
    this.videos = new Map();
    this.clips = new Map<string, Clip>();
    this.posts = new Map<string, Post>();
    this.socialAccounts = new Map<string, SocialAccount>();
    this.researchQueries = new Map<string, ResearchQuery>();
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { 
      ...insertUser, 
      id,
      firstName: insertUser.firstName || null,
      lastName: insertUser.lastName || null,
      profileImageUrl: insertUser.profileImageUrl || null,
      subscription: insertUser.subscription || "free",
      createdAt: new Date(),
      updatedAt: new Date()
    };
    this.users.set(id, user);
    return user;
  }

  async getProjects(): Promise<Project[]> {
    return Array.from(this.projects.values());
  }

  async getProject(id: string): Promise<Project | undefined> {
    return this.projects.get(id);
  }

  async createProject(insertProject: InsertProject): Promise<Project> {
    const id = randomUUID();
    const project: Project = { 
      ...insertProject, 
      id,
      description: insertProject.description || null,
      duration: insertProject.duration || null,
      aspectRatio: insertProject.aspectRatio || "9:16",
      viralScore: insertProject.viralScore || null,
      settings: insertProject.settings || null,
      status: insertProject.status || "draft",
      createdAt: new Date(),
      updatedAt: new Date()
    };
    this.projects.set(id, project);
    return project;
  }

  async updateProject(id: string, updates: Partial<Project>): Promise<Project> {
    const project = this.projects.get(id);
    if (!project) {
      throw new Error("Project not found");
    }
    const updatedProject = { ...project, ...updates, updatedAt: new Date() };
    this.projects.set(id, updatedProject);
    return updatedProject;
  }

  async getVideo(id: string): Promise<Video | undefined> {
    return this.videos.get(id);
  }

  async createVideo(insertVideo: InsertVideo): Promise<Video> {
    const id = randomUUID();
    const video: Video = { 
      ...insertVideo, 
      id,
      fileSize: insertVideo.fileSize || null,
      duration: insertVideo.duration || null,
      format: insertVideo.format || null,
      resolution: insertVideo.resolution || null,
      transcript: insertVideo.transcript || null,
      createdAt: new Date()
    };
    this.videos.set(id, video);
    return video;
  }

  async getClips(): Promise<Clip[]> {
    return Array.from(this.clips.values());
  }

  async getClip(id: string): Promise<Clip | undefined> {
    return this.clips.get(id);
  }

  async createClip(insertClip: InsertClip): Promise<Clip> {
    const id = randomUUID();
    const clip: Clip = { 
      ...insertClip, 
      id,
      title: insertClip.title || null,
      description: insertClip.description || null,
      tags: insertClip.tags || null,
      viralPotential: insertClip.viralPotential || null,
      thumbnail: insertClip.thumbnail || null,
      status: insertClip.status || "pending",
      createdAt: new Date()
    };
    this.clips.set(id, clip);
    return clip;
  }

  async getSocialAccounts(): Promise<SocialAccount[]> {
    return Array.from(this.socialAccounts.values());
  }

  async getSocialAccount(id: string): Promise<SocialAccount | undefined> {
    return this.socialAccounts.get(id);
  }

  async createSocialAccount(insertAccount: InsertSocialAccount): Promise<SocialAccount> {
    const id = randomUUID();
    const account: SocialAccount = { 
      ...insertAccount, 
      id,
      refreshToken: insertAccount.refreshToken || null,
      expiresAt: insertAccount.expiresAt || null,
      isActive: insertAccount.isActive !== false,
      createdAt: new Date()
    };
    this.socialAccounts.set(id, account);
    return account;
  }

  async getPosts(): Promise<Post[]> {
    return Array.from(this.posts.values());
  }

  async createPost(insertPost: InsertPost): Promise<Post> {
    const id = randomUUID();
    const post: Post = { 
      ...insertPost, 
      id,
      postId: insertPost.postId || null,
      caption: insertPost.caption || null,
      hashtags: insertPost.hashtags || null,
      scheduledAt: insertPost.scheduledAt || null,
      postedAt: insertPost.postedAt || null,
      analytics: insertPost.analytics || null,
      status: insertPost.status || "scheduled",
      createdAt: new Date()
    };
    this.posts.set(id, post);
    return post;
  }

  async getResearchQueries(): Promise<ResearchQuery[]> {
    return Array.from(this.researchQueries.values());
  }

  async createResearchQuery(insertQuery: InsertResearchQuery): Promise<ResearchQuery> {
    const id = randomUUID();
    const query: ResearchQuery = { 
      ...insertQuery, 
      id,
      results: insertQuery.results || null,
      status: insertQuery.status || "processing",
      createdAt: new Date()
    };
    this.researchQueries.set(id, query);
    return query;
  }

  getVideos(): Video[] {
    return Array.from(this.videos.values());
  }
}

export const storage = new MemStorage();