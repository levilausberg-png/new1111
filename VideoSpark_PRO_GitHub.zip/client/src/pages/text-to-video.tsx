import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Textarea } from "@/components/ui/textarea";
import { 
  Video, 
  Wand2, 
  Sparkles, 
  Play, 
  Download, 
  Settings, 
  Zap, 
  Clock, 
  Eye, 
  Palette,
  Music,
  Type,
  ImageIcon,
  Mic,
  Upload,
  RefreshCw,
  Target,
  TrendingUp,
  Brain,
  Rocket
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

interface GenerationRequest {
  prompt: string;
  style: string;
  duration: number;
  aspectRatio: string;
  voiceOver: boolean;
  music: boolean;
  platform: string;
}

interface GenerationResult {
  id: string;
  videoUrl: string;
  thumbnailUrl: string;
  duration: number;
  status: "generating" | "completed" | "failed";
  prompt: string;
  createdAt: string;
}

export default function TextToVideo() {
  const { toast } = useToast();
  const [prompt, setPrompt] = useState("");
  const [style, setStyle] = useState("realistic");
  const [duration, setDuration] = useState(15);
  const [aspectRatio, setAspectRatio] = useState("9:16");
  const [voiceOver, setVoiceOver] = useState(true);
  const [music, setMusic] = useState(true);
  const [platform, setPlatform] = useState("tiktok");
  const [isGenerating, setIsGenerating] = useState(false);
  
  // Fetch previous generations
  const { data: generations = [], isLoading } = useQuery({
    queryKey: ["/api/text-to-video/generations"],
  });
  
  // Generate video mutation
  const generateVideoMutation = useMutation({
    mutationFn: async (data: GenerationRequest) => {
      return apiRequest("/api/text-to-video/generate", {
        method: "POST",
        body: JSON.stringify(data),
        headers: { "Content-Type": "application/json" },
      });
    },
    onSuccess: (data) => {
      toast({
        title: "Video Generation Started",
        description: `Your AI video is being created. This may take 2-5 minutes.`,
      });
      setIsGenerating(false);
      setPrompt("");
    },
    onError: () => {
      toast({
        title: "Generation Failed",
        description: "Could not start video generation. Please try again.",
        variant: "destructive",
      });
      setIsGenerating(false);
    },
  });
  
  const handleGenerate = () => {
    if (!prompt.trim()) return;
    
    setIsGenerating(true);
    generateVideoMutation.mutate({
      prompt,
      style,
      duration,
      aspectRatio,
      voiceOver,
      music,
      platform
    });
  };
  
  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };
  
  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed": return "bg-green-500";
      case "generating": return "bg-yellow-500";
      case "failed": return "bg-red-500";
      default: return "bg-gray-500";
    }
  };
  
  return (
    <div className="container mx-auto p-6 space-y-6">
      {/* Header */}
      <div className="text-center space-y-4">
        <div className="flex justify-center items-center space-x-2">
          <Video className="h-8 w-8 text-purple-500" />
          <h1 className="text-3xl font-bold bg-gradient-to-r from-purple-500 to-blue-500 bg-clip-text text-transparent">
            AI Text-to-Video Generator
          </h1>
          <Sparkles className="h-8 w-8 text-yellow-500" />
        </div>
        <p className="text-muted-foreground max-w-2xl mx-auto">
          Transform your ideas into viral videos with our advanced AI video generation technology
        </p>
      </div>
      
      <div className="grid gap-6 lg:grid-cols-3">
        {/* Generation Panel */}
        <div className="lg:col-span-1">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Wand2 className="h-5 w-5 text-purple-500" />
                <span>Video Generator</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Prompt Input */}
              <div>
                <Label htmlFor="prompt">Video Description</Label>
                <Textarea
                  id="prompt"
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  placeholder="Describe the video you want to create... (e.g., 'A morning routine video showing productivity hacks with modern aesthetics and upbeat music')"
                  className="h-24 resize-none"
                />
                <p className="text-xs text-muted-foreground mt-1">
                  Be specific about visuals, mood, and style for best results
                </p>
              </div>
              
              {/* Style Selection */}
              <div>
                <Label>Visual Style</Label>
                <div className="grid grid-cols-2 gap-2 mt-2">
                  {["realistic", "animated", "cinematic", "minimalist"].map((styleOption) => (
                    <Button
                      key={styleOption}
                      variant={style === styleOption ? "default" : "outline"}
                      size="sm"
                      onClick={() => setStyle(styleOption)}
                      className="capitalize"
                    >
                      {styleOption}
                    </Button>
                  ))}
                </div>
              </div>
              
              {/* Duration */}
              <div>
                <Label htmlFor="duration">Duration (seconds)</Label>
                <div className="flex space-x-2 mt-2">
                  {[15, 30, 60].map((dur) => (
                    <Button
                      key={dur}
                      variant={duration === dur ? "default" : "outline"}
                      size="sm"
                      onClick={() => setDuration(dur)}
                    >
                      {dur}s
                    </Button>
                  ))}
                </div>
              </div>
              
              {/* Aspect Ratio */}
              <div>
                <Label>Aspect Ratio</Label>
                <div className="grid grid-cols-3 gap-2 mt-2">
                  {[
                    { ratio: "9:16", label: "TikTok" },
                    { ratio: "16:9", label: "YouTube" },
                    { ratio: "1:1", label: "Instagram" }
                  ].map(({ ratio, label }) => (
                    <Button
                      key={ratio}
                      variant={aspectRatio === ratio ? "default" : "outline"}
                      size="sm"
                      onClick={() => setAspectRatio(ratio)}
                    >
                      {label}
                    </Button>
                  ))}
                </div>
              </div>
              
              {/* Platform Optimization */}
              <div>
                <Label>Optimize For</Label>
                <select
                  value={platform}
                  onChange={(e) => setPlatform(e.target.value)}
                  className="w-full p-2 border rounded-md mt-2"
                >
                  <option value="tiktok">TikTok</option>
                  <option value="instagram">Instagram Reels</option>
                  <option value="youtube">YouTube Shorts</option>
                  <option value="all">All Platforms</option>
                </select>
              </div>
              
              {/* Audio Options */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Mic className="h-4 w-4" />
                    <Label>AI Voice-Over</Label>
                  </div>
                  <input
                    type="checkbox"
                    checked={voiceOver}
                    onChange={(e) => setVoiceOver(e.target.checked)}
                    className="rounded"
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Music className="h-4 w-4" />
                    <Label>Background Music</Label>
                  </div>
                  <input
                    type="checkbox"
                    checked={music}
                    onChange={(e) => setMusic(e.target.checked)}
                    className="rounded"
                  />
                </div>
              </div>
              
              {/* Generate Button */}
              <Button
                onClick={handleGenerate}
                disabled={!prompt.trim() || isGenerating}
                className="w-full bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600"
              >
                {isGenerating ? (
                  <>
                    <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                    Generating...
                  </>
                ) : (
                  <>
                    <Rocket className="h-4 w-4 mr-2" />
                    Generate Video
                  </>
                )}
              </Button>
              
              <p className="text-xs text-muted-foreground text-center">
                ⚡ Powered by advanced AI models for realistic video generation
              </p>
            </CardContent>
          </Card>
        </div>
        
        {/* Results Panel */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Video className="h-5 w-5" />
                <span>Generated Videos</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-96">
                {generations.length > 0 ? (
                  <div className="grid gap-4 md:grid-cols-2">
                    {generations.map((generation: GenerationResult) => (
                      <div key={generation.id} className="border rounded-lg overflow-hidden hover:shadow-md transition-shadow">
                        {/* Video Thumbnail */}
                        <div className="aspect-video bg-muted relative">
                          {generation.thumbnailUrl ? (
                            <img
                              src={generation.thumbnailUrl}
                              alt="Video thumbnail"
                              className="w-full h-full object-cover"
                            />
                          ) : (
                            <div className="flex items-center justify-center h-full">
                              <Video className="h-12 w-12 text-muted-foreground" />
                            </div>
                          )}
                          
                          {generation.status === "generating" && (
                            <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                              <div className="text-center text-white">
                                <RefreshCw className="h-8 w-8 mx-auto mb-2 animate-spin" />
                                <p className="text-sm">Generating...</p>
                              </div>
                            </div>
                          )}
                          
                          {generation.status === "completed" && (
                            <Button
                              variant="secondary"
                              size="sm"
                              className="absolute top-2 right-2"
                            >
                              <Play className="h-3 w-3" />
                            </Button>
                          )}
                        </div>
                        
                        {/* Video Info */}
                        <div className="p-4 space-y-3">
                          <div className="flex items-center justify-between">
                            <div className={`w-2 h-2 rounded-full ${getStatusColor(generation.status)}`} />
                            <Badge variant="secondary" className="text-xs">
                              {formatDuration(generation.duration)}
                            </Badge>
                          </div>
                          
                          <p className="text-sm text-muted-foreground line-clamp-2">
                            {generation.prompt}
                          </p>
                          
                          <div className="flex items-center justify-between">
                            <span className="text-xs text-muted-foreground">
                              {new Date(generation.createdAt).toLocaleDateString()}
                            </span>
                            
                            {generation.status === "completed" && (
                              <div className="flex space-x-1">
                                <Button size="sm" variant="ghost">
                                  <Download className="h-3 w-3" />
                                </Button>
                                <Button size="sm" variant="ghost">
                                  <Settings className="h-3 w-3" />
                                </Button>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <Video className="h-16 w-16 mx-auto text-muted-foreground mb-4" />
                    <h3 className="text-lg font-medium mb-2">No videos generated yet</h3>
                    <p className="text-muted-foreground mb-4">
                      Create your first AI-generated video using the prompt on the left
                    </p>
                    <div className="flex flex-wrap justify-center gap-2 text-sm text-muted-foreground">
                      <span>💡 Try prompts like:</span>
                      <Badge variant="secondary">"Morning productivity routine"</Badge>
                      <Badge variant="secondary">"Tech product showcase"</Badge>
                      <Badge variant="secondary">"Minimalist workspace tour"</Badge>
                    </div>
                  </div>
                )}
              </ScrollArea>
            </CardContent>
          </Card>
        </div>
      </div>
      
      {/* Tips Section */}
      <Card className="border-blue-200 dark:border-blue-800">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Brain className="h-5 w-5 text-blue-500" />
            <span>Pro Tips for Better Results</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-3">
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <Target className="h-4 w-4 text-green-500" />
                <h4 className="font-medium">Be Specific</h4>
              </div>
              <p className="text-sm text-muted-foreground">
                Include details about setting, mood, colors, and camera angles for better AI understanding
              </p>
            </div>
            
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <TrendingUp className="h-4 w-4 text-purple-500" />
                <h4 className="font-medium">Viral Elements</h4>
              </div>
              <p className="text-sm text-muted-foreground">
                Mention trending elements like "aesthetic", "satisfying", or "before/after"
              </p>
            </div>
            
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <Zap className="h-4 w-4 text-yellow-500" />
                <h4 className="font-medium">Platform Optimization</h4>
              </div>
              <p className="text-sm text-muted-foreground">
                Choose the right aspect ratio and duration for your target platform
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}