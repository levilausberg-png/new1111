import { useState } from "react";
import { Calendar, Clock, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

interface SocialAccount {
  platform: string;
  username: string;
  connected: boolean;
  icon: string;
  color: string;
}

export default function SocialMediaPanel() {
  const [scheduledTime, setScheduledTime] = useState("");
  const [socialAccounts] = useState<SocialAccount[]>([
    {
      platform: "TikTok",
      username: "@username",
      connected: true,
      icon: "fab fa-tiktok",
      color: "text-white"
    },
    {
      platform: "Instagram",
      username: "@username",
      connected: false,
      icon: "fab fa-instagram",
      color: "text-pink-400"
    },
    {
      platform: "YouTube",
      username: "Not connected",
      connected: false,
      icon: "fab fa-youtube",
      color: "text-red-400"
    }
  ]);

  const handleConnect = (platform: string) => {
    // In real implementation, this would initiate OAuth flow
    console.log(`Connecting to ${platform}`);
  };

  return (
    <div className="p-4 videospark-border border-b">
      <h3 className="text-sm font-semibold text-gray-300 mb-3">Auto-Post Settings</h3>
      
      <div className="space-y-3">
        {socialAccounts.map((account) => (
          <div key={account.platform} className="flex items-center justify-between p-3 videospark-primary-700 rounded-lg">
            <div className="flex items-center space-x-3">
              <i className={`${account.icon} ${account.color} text-lg`} />
              <div>
                <p className="text-sm font-medium">{account.platform}</p>
                <p className="text-xs text-gray-400">{account.username}</p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              {account.connected ? (
                <>
                  <div className="w-2 h-2 bg-green-400 rounded-full" />
                  <span className="text-xs text-green-400">Connected</span>
                </>
              ) : (
                <Button 
                  size="sm" 
                  className="text-xs videospark-accent-600 hover:videospark-accent-700 px-3 py-1 transition-colors"
                  onClick={() => handleConnect(account.platform)}
                >
                  Connect
                </Button>
              )}
            </div>
          </div>
        ))}

        <div className="mt-4">
          <Label className="block text-xs text-gray-400 mb-2">Schedule Post</Label>
          <div className="flex space-x-2">
            <Input
              type="datetime-local"
              value={scheduledTime}
              onChange={(e) => setScheduledTime(e.target.value)}
              className="flex-1 videospark-primary-700 videospark-border border-gray-600 text-sm focus:border-purple-500"
            />
            <Button className="bg-green-600 hover:bg-green-700 px-3 py-2 transition-colors">
              <Clock className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
