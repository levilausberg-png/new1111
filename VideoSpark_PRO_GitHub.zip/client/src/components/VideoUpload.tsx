import { useState, useCallback } from "react";
import { Upload, X, CheckCircle, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

interface VideoUploadProps {
  onUpload?: (result: any) => void;
}

export default function VideoUpload({ onUpload }: VideoUploadProps) {
  const [isDragOver, setIsDragOver] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [uploadStatus, setUploadStatus] = useState<'idle' | 'uploading' | 'success' | 'error'>('idle');
  const { toast } = useToast();

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    
    const files = Array.from(e.dataTransfer.files);
    const videoFiles = files.filter(file => file.type.startsWith('video/'));
    
    if (videoFiles.length > 0) {
      handleUpload(videoFiles[0]);
    }
  }, []);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      handleUpload(file);
    }
  };

  const handleUpload = async (file: File) => {
    setUploading(true);
    setUploadStatus('uploading');

    try {
      const formData = new FormData();
      formData.append('video', file);
      formData.append('projectId', 'default-project');

      const response = await fetch('/api/videos/upload', {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) {
        throw new Error('Upload failed');
      }

      const result = await response.json();
      setUploadStatus('success');
      onUpload?.(result);
      
      toast({
        title: "Upload Complete",
        description: "Video uploaded and processed successfully!",
      });
    } catch (error) {
      setUploadStatus('error');
      toast({
        title: "Upload Failed",
        description: "Failed to upload video. Please try again.",
        variant: "destructive",
      });
    } finally {
      setUploading(false);
    }
  };

  const getUploadIcon = () => {
    switch (uploadStatus) {
      case 'uploading':
        return <div className="animate-spin w-6 h-6 border-2 border-purple-500 border-t-transparent rounded-full" />;
      case 'success':
        return <CheckCircle className="w-6 h-6 text-green-500" />;
      case 'error':
        return <AlertCircle className="w-6 h-6 text-red-500" />;
      default:
        return <Upload className="w-6 h-6 text-gray-500" />;
    }
  };

  const getUploadText = () => {
    switch (uploadStatus) {
      case 'uploading':
        return 'Processing video...';
      case 'success':
        return 'Upload complete';
      case 'error':
        return 'Upload failed';
      default:
        return 'Drop video files here or';
    }
  };

  return (
    <div 
      className={`border-2 border-dashed rounded-lg p-6 text-center transition-colors cursor-pointer ${
        isDragOver 
          ? 'border-purple-500 bg-purple-500/10' 
          : uploadStatus === 'success'
            ? 'border-green-500 bg-green-500/10'
            : uploadStatus === 'error'
              ? 'border-red-500 bg-red-500/10'
              : 'videospark-border border-gray-600 hover:border-purple-500'
      }`}
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
    >
      <input
        type="file"
        accept="video/*"
        onChange={handleFileSelect}
        className="hidden"
        id="video-upload"
        disabled={uploading}
      />
      
      <div className="flex flex-col items-center space-y-2">
        {getUploadIcon()}
        <p className="text-sm text-gray-400">{getUploadText()}</p>
        {uploadStatus === 'idle' && (
          <label htmlFor="video-upload">
            <Button 
              variant="ghost" 
              className="text-purple-500 hover:text-purple-400 text-sm font-medium cursor-pointer"
              asChild
            >
              <span>browse files</span>
            </Button>
          </label>
        )}
        {uploadStatus === 'error' && (
          <label htmlFor="video-upload">
            <Button 
              variant="ghost" 
              className="text-red-500 hover:text-red-400 text-sm font-medium cursor-pointer"
              asChild
            >
              <span>try again</span>
            </Button>
          </label>
        )}
      </div>
    </div>
  );
}
