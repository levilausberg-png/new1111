import { Video, Music, Captions } from "lucide-react";

export default function TimelineEditor() {
  return (
    <div className="space-y-2">
      {/* Video Track */}
      <div className="flex items-center">
        <div className="w-20 text-xs text-gray-400 font-medium">Video</div>
        <div className="flex-1 h-12 videospark-primary-700 rounded relative overflow-hidden">
          <div className="absolute inset-y-1 left-2 right-20 videospark-accent-600 rounded flex items-center px-2 cursor-move hover:videospark-accent-500 transition-colors">
            <Video className="w-3 h-3 mr-2" />
            <span className="text-xs font-medium truncate">main_video.mp4</span>
          </div>
        </div>
      </div>

      {/* Audio Track */}
      <div className="flex items-center">
        <div className="w-20 text-xs text-gray-400 font-medium">Audio</div>
        <div className="flex-1 h-8 videospark-primary-700 rounded relative overflow-hidden">
          <div className="absolute inset-y-1 left-2 right-20 bg-green-600 rounded flex items-center px-2 cursor-move hover:bg-green-500 transition-colors">
            <Music className="w-3 h-3 mr-2" />
            <span className="text-xs font-medium">Background Music</span>
          </div>
        </div>
      </div>

      {/* Subtitle Track */}
      <div className="flex items-center">
        <div className="w-20 text-xs text-gray-400 font-medium">Subtitles</div>
        <div className="flex-1 h-8 videospark-primary-700 rounded relative overflow-hidden">
          <div className="absolute inset-y-1 left-6 right-32 bg-yellow-600 rounded flex items-center px-2 cursor-move hover:bg-yellow-500 transition-colors">
            <Captions className="w-3 h-3 mr-2" />
            <span className="text-xs font-medium">Auto Captions</span>
          </div>
        </div>
      </div>

      {/* Timeline Ruler */}
      <div className="mt-4 flex items-center">
        <div className="w-20"></div>
        <div className="flex-1 flex justify-between text-xs text-gray-500 font-mono">
          <span>0:00</span>
          <span>0:30</span>
          <span>1:00</span>
          <span>1:30</span>
          <span>2:00</span>
        </div>
      </div>
    </div>
  );
}
